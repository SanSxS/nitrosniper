const Discord = require("discord.js");
const Discord1 = require('discord.js-selfbot');
const axios = require('axios').default;
const config = require("./config.json")
const keepAlive = require('./server');
const id = config.id;
const token = config.token;
const seconds = config.delay;
const fetch = require("node-fetch");
const client = new Discord.Client();
const client1 = new Discord1.Client();


//Nitro Sniper 
client.on('ready', () => {
	console.log(``)
});

client.on('message', message => {
    if(message.content.includes('discord.gift') || message.content.includes('discordapp.com/gifts/') || message.content.includes('discord.com/gifts/')) {

        var Nitro = /(discord\.(gift)|discord\.com\/gift|discord\.com\/gifts|discordapp\.com\/gift)\/.+[a-z]/

        var NitroUrl = Nitro.exec(message.content);
        var Code = NitroUrl[0].split('/')[1];

        console.log(`[-] Found a Code | ${Code} | ${message.guild.name}`);

        axios({
            method: 'POST',
            url: `https://discordapp.com/api/v8/entitlements/gift-codes/${Code}/redeem`,
            headers:
            {
                'Authorization': client.token
            }
        }).then(
            () => console.log(`[+] Sniped Code | ${Code} | ${message.guild.name}`)

        ).catch(ex => console.log(`[x] Fake Code / Already Claimed - ${Code}`))

    }
})

//Giveaway Sniper

client1.on("ready", () => {
	console.log(`[Giveaway Sniper + Nitro Sniper]`)
    console.log(`[+] Snipers Activated on ${client1.guilds.cache.size} servers`)
    console.log(`[-] Client Account: ${client1.user.tag}`)
    console
});

client1.on('message', message => {
    if (message.author.id === "294882584201003009" && message.content.includes(`**GIVEAWAY**`)) {
        setTimeout(function() {
            message.react('🎉');
            console.log(`[-] Enter Giveaway | #${message.channel.name} | Guild : ${message.guild.name}\n`)
        }, seconds * 1000);
    };

    if (message.author.id === "294882584201003009" && message.content.includes(`Congratulations <@${id}>!`)) {
            console.log(`[+] Won Giveaway on ${message.guild.name} | #${message.channel.name}`)
            console.log(`[-] Prize: ${message.content.replace("Congratulations <@", "").replace('! You won the **', "").replace("**!\n<https://discordapp.com/channels", "").replace(/([/][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9])/g, "").replace(">", "").replace(id, "").replace(">", "")}`)
  };
});

client.on('dnd', ()=>{
client.channels.cache.get
}) 

client.login("NTQ0ODgyMjg1OTM0MDE4NTcx.YEW7tA.rtMle7Fy2-pbYusujU-QD3UvQQE")
client1.login("NTQ0ODgyMjg1OTM0MDE4NTcx.YEW7tA.rtMle7Fy2-pbYusujU-QD3UvQQE")