const express = require('express');
const server = express();
module.exports = keepAlive;
server.all('/', (req, res)=>{
    res.send('www.youtube.com/channel/UCh6X9fgLhcPEuyv1BZ7qMCg')
})

function keepAlive(){
    server.listen(3000, ()=>{console.log("Subscribe 𝙉𝙞𝙉𝙟4𝙃𝘼𝙓 or gay\n")});
}

keepAlive();
